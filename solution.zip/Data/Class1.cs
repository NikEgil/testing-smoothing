﻿using System;

namespace Data
{
    public static  class datalib
    {
        public int[] mas;
    }
}
