﻿namespace test
{
    partial class form_gen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_gen));
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.button1 = new System.Windows.Forms.Button();
            this.UD_Q_min = new System.Windows.Forms.DomainUpDown();
            this.UD_Q_max = new System.Windows.Forms.DomainUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 195);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(161, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Сгенерировать сглаженный";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // UD_Q_min
            // 
            this.UD_Q_min.Items.Add("50");
            this.UD_Q_min.Items.Add("49");
            this.UD_Q_min.Items.Add("48");
            this.UD_Q_min.Items.Add("47");
            this.UD_Q_min.Items.Add("46");
            this.UD_Q_min.Items.Add("45");
            this.UD_Q_min.Items.Add("44");
            this.UD_Q_min.Items.Add("43");
            this.UD_Q_min.Items.Add("42");
            this.UD_Q_min.Items.Add("41");
            this.UD_Q_min.Items.Add("40");
            this.UD_Q_min.Items.Add("39");
            this.UD_Q_min.Items.Add("38");
            this.UD_Q_min.Items.Add("37");
            this.UD_Q_min.Items.Add("36");
            this.UD_Q_min.Items.Add("35");
            this.UD_Q_min.Items.Add("34");
            this.UD_Q_min.Items.Add("33");
            this.UD_Q_min.Items.Add("32");
            this.UD_Q_min.Items.Add("31");
            this.UD_Q_min.Items.Add("30");
            this.UD_Q_min.Items.Add("29");
            this.UD_Q_min.Items.Add("28");
            this.UD_Q_min.Items.Add("27");
            this.UD_Q_min.Items.Add("26");
            this.UD_Q_min.Items.Add("25");
            this.UD_Q_min.Items.Add("24");
            this.UD_Q_min.Items.Add("23");
            this.UD_Q_min.Items.Add("22");
            this.UD_Q_min.Items.Add("21");
            this.UD_Q_min.Items.Add("20");
            this.UD_Q_min.Items.Add("19");
            this.UD_Q_min.Items.Add("18");
            this.UD_Q_min.Items.Add("17");
            this.UD_Q_min.Items.Add("16");
            this.UD_Q_min.Items.Add("15");
            this.UD_Q_min.Items.Add("14");
            this.UD_Q_min.Items.Add("13");
            this.UD_Q_min.Items.Add("12");
            this.UD_Q_min.Items.Add("11");
            this.UD_Q_min.Items.Add("10");
            this.UD_Q_min.Items.Add("9");
            this.UD_Q_min.Items.Add("8");
            this.UD_Q_min.Items.Add("7");
            this.UD_Q_min.Location = new System.Drawing.Point(12, 51);
            this.UD_Q_min.Name = "UD_Q_min";
            this.UD_Q_min.Size = new System.Drawing.Size(60, 20);
            this.UD_Q_min.TabIndex = 1;
            this.UD_Q_min.Text = "7";
            // 
            // UD_Q_max
            // 
            this.UD_Q_max.Items.Add("50");
            this.UD_Q_max.Items.Add("49");
            this.UD_Q_max.Items.Add("48");
            this.UD_Q_max.Items.Add("47");
            this.UD_Q_max.Items.Add("46");
            this.UD_Q_max.Items.Add("45");
            this.UD_Q_max.Items.Add("44");
            this.UD_Q_max.Items.Add("43");
            this.UD_Q_max.Items.Add("42");
            this.UD_Q_max.Items.Add("41");
            this.UD_Q_max.Items.Add("40");
            this.UD_Q_max.Items.Add("39");
            this.UD_Q_max.Items.Add("38");
            this.UD_Q_max.Items.Add("37");
            this.UD_Q_max.Items.Add("36");
            this.UD_Q_max.Items.Add("35");
            this.UD_Q_max.Items.Add("34");
            this.UD_Q_max.Items.Add("33");
            this.UD_Q_max.Items.Add("32");
            this.UD_Q_max.Items.Add("31");
            this.UD_Q_max.Items.Add("30");
            this.UD_Q_max.Items.Add("29");
            this.UD_Q_max.Items.Add("28");
            this.UD_Q_max.Items.Add("27");
            this.UD_Q_max.Items.Add("26");
            this.UD_Q_max.Items.Add("25");
            this.UD_Q_max.Items.Add("24");
            this.UD_Q_max.Items.Add("23");
            this.UD_Q_max.Items.Add("22");
            this.UD_Q_max.Items.Add("21");
            this.UD_Q_max.Items.Add("20");
            this.UD_Q_max.Items.Add("19");
            this.UD_Q_max.Items.Add("18");
            this.UD_Q_max.Items.Add("17");
            this.UD_Q_max.Items.Add("16");
            this.UD_Q_max.Items.Add("15");
            this.UD_Q_max.Items.Add("14");
            this.UD_Q_max.Items.Add("13");
            this.UD_Q_max.Items.Add("12");
            this.UD_Q_max.Items.Add("11");
            this.UD_Q_max.Items.Add("10");
            this.UD_Q_max.Items.Add("9");
            this.UD_Q_max.Items.Add("8");
            this.UD_Q_max.Items.Add("7");
            this.UD_Q_max.Location = new System.Drawing.Point(113, 51);
            this.UD_Q_max.Name = "UD_Q_max";
            this.UD_Q_max.Size = new System.Drawing.Size(60, 20);
            this.UD_Q_max.TabIndex = 2;
            this.UD_Q_max.Text = "50";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 39);
            this.label1.TabIndex = 3;
            this.label1.Text = "Пределы генерируемого\r\nнапряжения Q,B\r\n(  7  -  50  )  /  10";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 26);
            this.label2.TabIndex = 5;
            this.label2.Text = "Время между имульсами\r\nнаносекунд : 150";
            // 
            // trackBar2
            // 
            this.trackBar2.LargeChange = 10;
            this.trackBar2.Location = new System.Drawing.Point(12, 142);
            this.trackBar2.Maximum = 300;
            this.trackBar2.Minimum = 1;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Size = new System.Drawing.Size(161, 45);
            this.trackBar2.TabIndex = 9;
            this.trackBar2.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar2.Value = 1;
            this.trackBar2.Scroll += new System.EventHandler(this.trackBar2_Scroll);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(145, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Количество тысяч точек : 1";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 224);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(161, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "Сгенерировать с шумом";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // trackBar1
            // 
            this.trackBar1.LargeChange = 20;
            this.trackBar1.Location = new System.Drawing.Point(12, 103);
            this.trackBar1.Maximum = 400;
            this.trackBar1.Minimum = 20;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(161, 45);
            this.trackBar1.TabIndex = 11;
            this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBar1.Value = 150;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(12, 172);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(86, 17);
            this.checkBox1.TabIndex = 12;
            this.checkBox1.Text = "убрать нули";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // form_gen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(185, 259);
            this.ControlBox = false;
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.trackBar2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.UD_Q_max);
            this.Controls.Add(this.UD_Q_min);
            this.Controls.Add(this.trackBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "form_gen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Генератор пиков";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DomainUpDown UD_Q_max;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.DomainUpDown UD_Q_min;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}